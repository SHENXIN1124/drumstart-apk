# DrumStart（鼓点入门）第一版

一个免费的、离线优先的 Kivy 安卓架子鼓练习项目。鼓声 WAV 文件由项目脚本合成，不依赖商业采样。

## 当前功能
- 自由弹奏：底鼓、军鼓、踩镲、通鼓、落地通鼓、吊镲、Ride。
- 简易节拍器，可调 40–160 BPM。
- 入门摇滚节奏提示课程。
- 无账号、无广告、无网络请求。

## 项目结构
```
DrumStart/
├── main.py
├── buildozer.spec
├── README.md
└── assets/
    └── sounds/
        ├── kick.wav
        ├── snare.wav
        ├── hihat.wav
        ├── tom1.wav
        ├── tom2.wav
        ├── floortom.wav
        ├── crash.wav
        └── ride.wav
```

## 在 Linux / Ubuntu 上先运行桌面版
建议 Python 3.10–3.12。
```
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install "kivy[base]"
python main.py
```

## Windows 用户
建议安装 WSL2 + Ubuntu，然后把项目复制到 Linux 家目录再构建，不要直接在 `/mnt/c/...` 下构建。
参考：https://learn.microsoft.com/windows/wsl/install

## 打包 Android APK（Ubuntu / WSL2）
先安装系统依赖：
```
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip python3-venv \
  autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev \
  libtinfo6 cmake libffi-dev libssl-dev automake autopoint gettext
```
安装 Buildozer：
```
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip setuptools wheel
pip install buildozer cython
```
项目根目录已有 `buildozer.spec`，执行：
```
buildozer -v android debug
```
首次构建会下载 Android SDK/NDK 等组件，耗时较长并需要网络。成功后 APK 在 `bin/` 目录中。

把 APK 复制到手机，允许该来源安装应用后点击安装。也可以开启 USB 调试并连接手机，使用：
```
buildozer android debug deploy run
```

## 重要说明
- 本项目是可继续开发的第一版示例，不保证在所有设备/音频后端上都达到专业鼓机的低延迟。
- 当前课程提供节拍提示与简单命中计数，尚未实现严格的时间窗口评分、课程保存、录音、MIDI、真实多点触控鼓棒检测。
- 生成的鼓声是程序合成的基础音色，并非真实录音采样；后续可以替换成有明确免费授权的 WAV 样本。
- 第一次构建前请检查 Buildozer 官方文档中的最新系统依赖和工具链说明。
