__version__ = "0.1.0"

import os
import random
from kivy.app import App
from kivy.clock import Clock
from kivy.core.audio import SoundLoader
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.slider import Slider
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.widget import Widget
from kivy.graphics import Color, RoundedRectangle

APP_DIR = os.path.dirname(os.path.abspath(__file__))
SOUND_DIR = os.path.join(APP_DIR, "assets", "sounds")

PAD_SOUNDS = {
    "CRASH": "crash.wav",
    "RIDE": "ride.wav",
    "HI-HAT": "hihat.wav",
    "TOM 1": "tom1.wav",
    "TOM 2": "tom2.wav",
    "FLOOR TOM": "floortom.wav",
    "SNARE": "snare.wav",
    "KICK": "kick.wav",
    "CLOSED HAT": "hihat.wav",
}

PAD_COLORS = {
    "CRASH": (0.88, 0.56, 0.18, 1),
    "RIDE": (0.82, 0.66, 0.25, 1),
    "HI-HAT": (0.82, 0.66, 0.25, 1),
    "TOM 1": (0.27, 0.46, 0.65, 1),
    "TOM 2": (0.25, 0.40, 0.58, 1),
    "FLOOR TOM": (0.22, 0.35, 0.51, 1),
    "SNARE": (0.70, 0.28, 0.26, 1),
    "KICK": (0.22, 0.25, 0.30, 1),
    "CLOSED HAT": (0.65, 0.54, 0.23, 1),
}

# Beginner rock groove: 1 & 2 & 3 & 4 &
LESSON = [
    ("KICK", "1"), ("CLOSED HAT", "&"), ("SNARE", "2"),
    ("CLOSED HAT", "&"), ("KICK", "3"), ("CLOSED HAT", "&"),
    ("SNARE", "4"), ("CLOSED HAT", "&"),
]

class DrumPad(Button):
    def __init__(self, drum_name, **kwargs):
        self.drum_name = drum_name
        color = PAD_COLORS.get(drum_name, (0.3, 0.3, 0.3, 1))
        super().__init__(text=drum_name, bold=True, font_size="15sp",
                         color=(1, 1, 1, 1), background_normal="",
                         background_down="", **kwargs)
        with self.canvas.before:
            Color(*color)
            self._shape = RoundedRectangle(pos=self.pos, size=self.size, radius=[dp(14)])
        self.bind(pos=self._update_shape, size=self._update_shape)

    def _update_shape(self, *_):
        self._shape.pos = self.pos
        self._shape.size = self.size

class DrumStartApp(App):
    def build(self):
        self.title = "DrumStart - 免费架子鼓练习"
        self.sounds = {}
        self.sound_pools = {}
        self.bpm = 60
        self.metronome_event = None
        self.lesson_event = None
        self.lesson_index = 0
        self.lesson_running = False
        self.lesson_score = 0
        self.lesson_total = 0
        self.current_mode = "play"

        self.load_sounds()

        root = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        with root.canvas.before:
            Color(0.075, 0.09, 0.12, 1)
            self.bg = RoundedRectangle(pos=root.pos, size=root.size, radius=[0])
        root.bind(pos=self._update_bg, size=self._update_bg)

        header = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        header.add_widget(Label(text="[b]DRUM START[/b]  |  免费架子鼓", markup=True,
                                font_size="20sp", halign="left"))
        self.status = Label(text="自由弹奏：点击鼓件发声", font_size="14sp")
        header.add_widget(self.status)
        root.add_widget(header)

        nav = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        self.play_tab = ToggleButton(text="自由弹奏", group="mode", state="down")
        self.lesson_tab = ToggleButton(text="新手课程", group="mode")
        self.play_tab.bind(on_release=lambda *_: self.show_mode("play"))
        self.lesson_tab.bind(on_release=lambda *_: self.show_mode("lesson"))
        nav.add_widget(self.play_tab)
        nav.add_widget(self.lesson_tab)
        root.add_widget(nav)

        self.content = BoxLayout(orientation="vertical", spacing=dp(6))
        root.add_widget(self.content)
        self.show_mode("play")
        return root

    def _update_bg(self, widget, *_):
        self.bg.pos = widget.pos
        self.bg.size = widget.size

    def load_sounds(self):
        # A small pool lets repeated hits overlap instead of cutting off the previous hit.
        for pad, filename in PAD_SOUNDS.items():
            path = os.path.join(SOUND_DIR, filename)
            if not os.path.exists(path):
                continue
            pool = []
            for _ in range(4):
                snd = SoundLoader.load(path)
                if snd:
                    pool.append(snd)
            self.sound_pools[pad] = pool
            self.sounds[pad] = 0

    def play_drum(self, name):
        pool = self.sound_pools.get(name) or self.sound_pools.get("HI-HAT", [])
        if not pool:
            self.status.text = "没有加载到声音文件，请检查 assets/sounds"
            return
        idx = self.sounds.get(name, 0) % len(pool)
        snd = pool[idx]
        self.sounds[name] = idx + 1
        try:
            snd.stop()
            snd.play()
        except Exception:
            pass
        if self.current_mode == "lesson" and self.lesson_running:
            expected, beat = LESSON[self.lesson_index]
            if name == expected:
                self.lesson_score += 1
                self.status.text = "正确！继续保持节奏。"
            else:
                self.status.text = "提示：这一步试试敲 " + expected
            self.lesson_total += 1
            self.score_label.text = "练习次数：%d   命中：%d" % (self.lesson_total, self.lesson_score)

    def show_mode(self, mode):
        self.current_mode = mode
        self.stop_lesson()
        self.content.clear_widgets()
        if mode == "play":
            self.status.text = "自由弹奏：点击鼓件发声"
            self.build_play_screen()
        else:
            self.status.text = "课程 1：基础摇滚节奏"
            self.build_lesson_screen()

    def build_play_screen(self):
        top = BoxLayout(size_hint_y=None, height=dp(42), spacing=dp(8))
        top.add_widget(Label(text="速度 BPM", size_hint_x=None, width=dp(90)))
        self.tempo_label = Label(text=str(self.bpm), size_hint_x=None, width=dp(45))
        tempo = Slider(min=40, max=160, value=self.bpm)
        tempo.bind(value=self.set_tempo)
        top.add_widget(tempo)
        top.add_widget(self.tempo_label)
        self.metro_button = Button(text="启动节拍器", size_hint_x=None, width=dp(135))
        self.metro_button.bind(on_release=self.toggle_metronome)
        top.add_widget(self.metro_button)
        self.content.add_widget(top)

        # A visually arranged, touch-friendly drum kit.
        kit = GridLayout(cols=4, spacing=dp(8), padding=dp(4))
        kit.add_widget(DrumPad("CRASH", on_release=lambda *_: self.play_drum("CRASH")))
        kit.add_widget(DrumPad("TOM 1", on_release=lambda *_: self.play_drum("TOM 1")))
        kit.add_widget(DrumPad("TOM 2", on_release=lambda *_: self.play_drum("TOM 2")))
        kit.add_widget(DrumPad("RIDE", on_release=lambda *_: self.play_drum("RIDE")))
        kit.add_widget(DrumPad("HI-HAT", on_release=lambda *_: self.play_drum("HI-HAT")))
        kit.add_widget(DrumPad("SNARE", on_release=lambda *_: self.play_drum("SNARE")))
        kit.add_widget(DrumPad("FLOOR TOM", on_release=lambda *_: self.play_drum("FLOOR TOM")))
        kit.add_widget(DrumPad("CLOSED HAT", on_release=lambda *_: self.play_drum("CLOSED HAT")))
        kit.add_widget(Widget())
        kit.add_widget(DrumPad("KICK", on_release=lambda *_: self.play_drum("KICK")))
        kit.add_widget(Widget())
        kit.add_widget(Widget())
        self.content.add_widget(kit)

        hint = Label(text="提示：这是第一版触屏鼓组。耳机通常能获得更清晰的鼓声。", size_hint_y=None, height=dp(28))
        self.content.add_widget(hint)

    def set_tempo(self, _slider, value):
        self.bpm = int(value)
        if hasattr(self, "tempo_label"):
            self.tempo_label.text = str(self.bpm)
        if self.metronome_event is not None:
            self.stop_metronome()
            self.start_metronome()

    def toggle_metronome(self, *_):
        if self.metronome_event is None:
            self.start_metronome()
            self.metro_button.text = "停止节拍器"
        else:
            self.stop_metronome()
            self.metro_button.text = "启动节拍器"

    def start_metronome(self):
        self.metronome_event = Clock.schedule_interval(self.metronome_tick, 60.0 / self.bpm)

    def stop_metronome(self):
        if self.metronome_event is not None:
            self.metronome_event.cancel()
            self.metronome_event = None

    def metronome_tick(self, _dt):
        # Use a short closed-hat sound as the metronome click.
        pool = self.sound_pools.get("CLOSED HAT", [])
        if pool:
            snd = pool[0]
            snd.stop()
            snd.play()

    def build_lesson_screen(self):
        intro = Label(text="[b]课程 1：基础摇滚节奏[/b]\n每小节 4 拍：底鼓在第 1、3 拍，军鼓在第 2、4 拍，踩镲保持八分音符。",
                      markup=True, halign="center", valign="middle", size_hint_y=None, height=dp(76))
        self.content.add_widget(intro)

        self.lesson_prompt = Label(text="准备好后点击“开始课程”。", font_size="22sp", size_hint_y=None, height=dp(54))
        self.content.add_widget(self.lesson_prompt)

        row = BoxLayout(size_hint_y=None, height=dp(60), spacing=dp(8))
        start = Button(text="开始课程")
        start.bind(on_release=self.start_lesson)
        stop = Button(text="暂停课程")
        stop.bind(on_release=lambda *_: self.stop_lesson())
        row.add_widget(start)
        row.add_widget(stop)
        self.content.add_widget(row)

        pads = GridLayout(cols=3, spacing=dp(8))
        for name in ("KICK", "SNARE", "CLOSED HAT"):
            pads.add_widget(DrumPad(name, on_release=lambda _btn, n=name: self.play_drum(n)))
        self.content.add_widget(pads)
        self.score_label = Label(text="练习次数：0   命中：0", size_hint_y=None, height=dp(30))
        self.content.add_widget(self.score_label)
        self.lesson_hint = Label(text="跟随提示，听节拍并敲击对应鼓件。当前版本为入门练习，不是专业精确评分。")
        self.content.add_widget(self.lesson_hint)

    def start_lesson(self, *_):
        self.stop_lesson()
        self.lesson_running = True
        self.lesson_index = 0
        self.lesson_event = Clock.schedule_interval(self.lesson_tick, 60.0 / self.bpm / 2)
        self.lesson_prompt.text = "开始！"

    def lesson_tick(self, _dt):
        name, beat = LESSON[self.lesson_index]
        self.lesson_prompt.text = "现在敲：%s    节拍：%s" % (name, beat)
        self.lesson_index = (self.lesson_index + 1) % len(LESSON)

    def stop_lesson(self):
        self.lesson_running = False
        if self.lesson_event is not None:
            self.lesson_event.cancel()
            self.lesson_event = None
        self.stop_metronome()
        if hasattr(self, "metro_button"):
            self.metro_button.text = "启动节拍器"

    def on_pause(self):
        self.stop_lesson()
        self.stop_metronome()
        return True

    def on_stop(self):
        self.stop_lesson()
        self.stop_metronome()

if __name__ == "__main__":
    DrumStartApp().run()
